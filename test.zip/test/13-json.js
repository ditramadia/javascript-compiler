const person = {
  first_name: "Asep",
  last_name: "NMax",
  age: 19,
  skill: ["photography", "football"],
  canRun: true,
  sayHello: hello(),
};
