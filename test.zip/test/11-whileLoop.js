while (i < a) {
  console.log(i + 5);

  i++;
}

while (item in [1, 2, 3, 4, 5]) {
  print(item);
}
