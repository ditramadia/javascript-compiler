const a_function = foo() {
  return false;
};
