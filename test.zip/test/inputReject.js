function do_something(x) {
    // This is a sample multiline comment
    if (x == 0) {
      return 0;
    } else if x + 4 == 1 {
      if (true) {
        return 3;
      } else {
        return 2;
      }
    } else if (x == 32) {
      return 4;
    } else {
      return "Momen";
    }
  }
  