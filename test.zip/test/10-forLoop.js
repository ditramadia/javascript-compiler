for (item in [1, 2, 3, 4, 5]) {
  console.log(test);
}

for (let i = 0; i < 10; i++) {
  if (i % 8 == 0) {
    break;
  }

  if (i != 5) {
    continue;
  }
}
