if (true) {
  import "module";
}
