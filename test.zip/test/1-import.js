import defaultExport from "module-name";
import * as name from "module-name";
import { export1 } from "module-name";
import "module-name";
