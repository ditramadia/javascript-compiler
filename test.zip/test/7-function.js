function helloWorld() {
  return "hello world";
}

const add = function (a, b) {
  return a + b;
};

const sub = function sub(a, b) {
  return a + b;
};

const hiWorld = () => {
  return "hi world";
};
