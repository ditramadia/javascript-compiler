console.log("hello");
this.person(isCrazy).append("tuh???");
this.person.not(isCrazy);
