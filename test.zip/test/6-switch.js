switch (gender) {
  case "men":
    ret = "cowok";
    break;
  case "women":
    ret = "cewek";
    break;
  default:
    ret = "cwk";
}
