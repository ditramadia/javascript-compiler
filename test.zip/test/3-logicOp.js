a = true;
a = 1;
a = "test";
a = isFoo && isFee;
a = isFee || isFaa;

let isDone = isCodeComplete && isLaporanConplete;
