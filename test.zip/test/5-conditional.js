if (score < 50) score = "D";
else if (score < 65) score = "C";
else score = "A";

if (score < 50) {
  score = "D";
} else if (score < 65) {
  score = "C";
} else {
  score = "A";
}
