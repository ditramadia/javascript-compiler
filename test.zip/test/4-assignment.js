let a = 1;
var b = 3;
const C = 5;
const _NIM_ = 1 + 3 + 5;

let arr = ["hi", 2];

delete arr;
